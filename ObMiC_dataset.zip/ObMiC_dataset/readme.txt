The object-based multiple foreground video co-segmentation (ObMiC) dataset.
If you use this dataset, please cite the follow paper:

"Object-based Multiple Foreground Video Co-segmentation", 
Huazhu Fu, Dong Xu, Bao Zhang, Stephen Lin, 
in IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2014, pp. 3166-3173